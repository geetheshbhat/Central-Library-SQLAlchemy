**********************************************************************************************************************************************
<--Welcome To Central Library-->

Please install SQLAlchemy and Pandas

jupyte Notebook uses Python 3.x:

> pip3 install sqlalchemy pandas

Except for one use case, i.e for levying late fees, I have coded all others.
Please feel free to call me, in case there are any doubts.
I have tried to keep the code as Pythonic as possible

***********************************************************************************************************************************************